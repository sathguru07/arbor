# Arbor Core

**Internal crate** for [Arbor](https://github.com/Anandb71/arbor).

This crate handles AST parsing using Tree-sitter. It is not intended for direct use.

See the [main repository](https://github.com/Anandb71/arbor) for documentation.
