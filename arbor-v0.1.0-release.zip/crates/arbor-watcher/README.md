# Arbor Watcher

**Internal crate** for [Arbor](https://github.com/Anandb71/arbor).

This crate handles file system watching and incremental indexing. It is not intended for direct use.

See the [main repository](https://github.com/Anandb71/arbor) for documentation.
