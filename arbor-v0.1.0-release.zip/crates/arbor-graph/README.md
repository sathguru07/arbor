# Arbor Graph

**Internal crate** for [Arbor](https://github.com/Anandb71/arbor).

This crate defines the graph schema and manages the in-memory graph structure. It is not intended for direct use.

See the [main repository](https://github.com/Anandb71/arbor) for documentation.
